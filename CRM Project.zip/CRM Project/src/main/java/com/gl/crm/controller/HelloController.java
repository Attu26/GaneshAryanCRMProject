package com.gl.crm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller


public class HelloController {
 
	@RequestMapping("/")
	
//@RequestMapping("/hello")
public String showMainPage() {
return "demo";
	}
}


